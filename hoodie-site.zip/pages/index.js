import React, { useState } from "react";

const teams = [
  { name: "AC Milan", image: "/hoodie1.png", price: 65, stock: 5 },
  { name: "Barcelona", image: "/hoodie2.png", price: 70, stock: 4 },
  { name: "PSG", image: "/hoodie3.png", price: 75, stock: 3 },
  { name: "Real Madrid", image: "/hoodie4.png", price: 80, stock: 2 },
];

export default function Home() {
  const [cart, setCart] = useState([]);

  function addToCart(team) {
    setCart([...cart, team]);
  }

  function removeFromCart(index) {
    setCart(cart.filter((_, i) => i !== index));
  }

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div style={{ padding: 20 }}>
      <h1>HoodieFC</h1>
      <h2>Cart ({cart.length})</h2>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 20 }}>
        {teams.map((team, i) => (
          <div key={i} style={{ border: "1px solid #ccc", padding: 10 }}>
            <img src={team.image} style={{ width: "100%" }} />
            <h3>{team.name}</h3>
            <p>${team.price}</p>
            <p style={{ color: "red" }}>Only {team.stock} left 🔥</p>
            <button onClick={() => addToCart(team)}>Add to Cart</button>
          </div>
        ))}
      </div>

      <h2>Your Cart</h2>
      {cart.map((item, i) => (
        <div key={i}>
          {item.name} - ${item.price}
          <button onClick={() => removeFromCart(i)}>Remove</button>
        </div>
      ))}

      <h3>Total: ${total}</h3>
    </div>
  );
}
