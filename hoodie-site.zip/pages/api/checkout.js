import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);

export default async function handler(req, res) {
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    line_items: [
      {
        price: "price_12345",
        quantity: 1,
      },
    ],
    mode: "payment",
    success_url: "https://example.com",
    cancel_url: "https://example.com",
  });

  res.redirect(303, session.url);
}
